  _______ _                 _          ______           _____                      _                 _ _               _ 
 |__   __| |               | |        |  ____|         |  __ \                    | |               | (_)             | |
    | |  | |__   __ _ _ __ | | _____  | |__ ___  _ __  | |  | | _____      ___ __ | | ___   __ _  __| |_ _ __   __ _  | |
    | |  | '_ \ / _` | '_ \| |/ / __| |  __/ _ \| '__| | |  | |/ _ \ \ /\ / / '_ \| |/ _ \ / _` |/ _` | | '_ \ / _` | | |
    | |  | | | | (_| | | | |   <\__ \ | | | (_) | |    | |__| | (_) \ V  V /| | | | | (_) | (_| | (_| | | | | | (_| | |_|
    |_|  |_| |_|\__,_|_| |_|_|\_\___/ |_|  \___/|_|    |_____/ \___/ \_/\_/ |_| |_|_|\___/ \__,_|\__,_|_|_| |_|\__, | (_)
                                                                                                                __/ |    
                                                                                                               |___/     

Hi there!! Thanks for downloading TDRP'S Sticker Pack Volume 1!

This sticker pack contains 6, 370×300 stickers to use! They include:

- Cheeky
- goober
- HELP ME
- Nice!
- ROCK ON!!
- Unsurprised

NOTE: You should use these in apps like Discord, iMessage, etc. This is because since
      their size is small (370×300), posting them in other apps may make them seem
      blurry instead of pixelated. Which was the way these stickers were intended to be
      shown as.
